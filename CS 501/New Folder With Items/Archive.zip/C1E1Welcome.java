import java.util.*;
class C1E1Welcome{
    public static void main(String args[]){
        /*
        Chapter 1 - Exercise 1.1
        Write a program that displays Welcome to Java,
        Learning Java Now, and Programming is fun.
        */
        System.out.println("Welcome to Java");
        System.out.println("Learning Java Now");
        System.out.println("Programming is fun");

    }
}