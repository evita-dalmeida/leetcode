import java.util.*;
class C1E13SolveLinearEquations{
    public static void main(String args[]){
        /* 
        Chapter 1 - Exercise 1.5
        Write a program that displays the result of ...*/
        System.out.println("Solving Linear Equations: ");
        double result = (7.5*6.5 - 4.5*3)/(47.5 - 5.5);
        System.out.println("Result : " + result);
    }
}